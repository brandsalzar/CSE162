package com.brandonsalazar.fragments;

public class Ipsum {
    static String[] Headlines = {
            "Article One",
            "Article Two"
    };
    static String[] Articles = {
            "Article One\n\n Exactly! I needed this thread. I felt this way last weekend. I was at a neighborhood summer party digging for a beer from the cooler. Someone else comes over to do the same and calls my name. I looked up…and there, on the path to making eye contact, was the low-cut tanktop exposure in front of me. It was quick, I panicked, and when I made eye contact, “I did the awkward teenage boy “hi…”. I realized it was a neighbor's wife I met earlier. She asked if I had “seen any water down there.” I directed her to the right cooler, and I darted to the other side of the party. It totally killed my buzz for the rest of the night.",
            "Article Two\n\n I read a random girls shirt to her walking into a store the other day. It said “y’all motherfuckers need science” with a picture of Neil Degrasse. The text was large. I was wearing sunglasses. I think I was okay but who knows."
    };
}
